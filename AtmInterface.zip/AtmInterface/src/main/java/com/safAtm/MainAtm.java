/**
 * MINI PROJECT
 * EduBridge Learning Pvt.Ltd.
 * Title: ATM INTERFACE
 * ATM INTERFACE PROJECT USING CORE JAVA AND MYSQL CONNECTOR.
 * I created Six Class  -> MainAtm,LoginPin,SetPin,DbConnection,AtmOperation,ChangePin
 * In MainAtm Class     -> To display the login and to generate the new pin page.
 * In Dbconnection Class-> To connect the MySql.
 * In LoginPage Class   -> To display the Menu of view Balance, Withdraw, Deposit,Mini Statement and Change ATM Pin.
 * In setPin Class      -> To Generate their New ATM Pin Number in particular Account Holder.
 * In ChangePin Class   -> To Change the Old ATM Pin Number to New ATM Pin Number in particular Account Holder.
 * In AtmOperation Class-> To implemented for performing a ATM Operations such as withdraw Amount,Deposit Amount,View Balance,View MiniStatement for user.
 * @DoneBy Tharani.M
 */

package com.safAtm;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Scanner;

public class MainAtm
{
	private static int choice;
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws SQLException 
	{
		// main menu
		while(true)
		{
			System.out.println("         $$$-WELCOME TO SAFE ATM-$$$       ");
			LocalDateTime current=LocalDateTime.now();
			System.out.println("********************SAFE ATM*********************");
			System.out.println(" DATE AND TIME :"+current+"\n");
			System.out.println("1.login");
			System.out.println("2.Generate the New ATM Pin");
			System.out.println("3.Exit");
			System.out.println("********************SAFE ATM*********************");
			System.out.println("Enter the choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: LoginPage.logIn();
			        break;  
			//LOGINPAGE BREAK
			case 2: SetPin.setPin();
			        break;                
			//SET PIN BREAK
			case 3: System.out.println("ENDING THE PROCESS.....THANK YOU......");
			        System.out.println(".........../HAVE A GOOD DAY/...........");
		        	System.exit(0);
		        	break;
		    //exit     	
			default:System.out.println("please enter vaild number!");
			}//end switch case
			System.out.println("**********DO YOU WANT TO CONTINUE (YES/NO)*********");
			String input=sc.next();
			if(input.equalsIgnoreCase("no"))
			{

				break;

			}
					
		}//while loop end
		System.out.println("ENDING THE PROCESS.....THANK YOU.....");
		System.out.println("............/HAVE A GOOD DAY/........");
	}

}
