package com.safAtm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Scanner;

public class AtmOperation 
{
	private static Connection scon=null;
	private static ResultSet rs,rs1;
	private static Statement st=null;
	private static int pinno,i,withdraw_amount,deposit_amount;
	private static String sql;
	private static int balance;
	private static Scanner sc=new Scanner(System.in);


	//VIEW BALANCE
	public static void checkBalance() throws SQLException 
	{
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the  4 digit Pin Number:");
		pinno=sc.nextInt();
		String a=String.valueOf(pinno);
		if(a.length()==4)
		{
			sql="select * from accountdetail where pinno="+pinno;
			rs=st.executeQuery(sql);
			if(rs.next())
			{		
				balance=rs.getInt("accountbalance");
				System.out.println("YOUR CURRENT BALANCE IS  Rs."+balance);
			}
			else
			{
				System.out.println("invalid pin number!");

			}
		}
		else
		{
			System.out.println("PLEASE ENTER THE 4 DIGIT PIN NUMBER.......");
		}

	}//view balance end

	//WITHDRAW AMOUNT
	public static void withdrawAmount() throws SQLException 
	{
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the Pin Number:");
		pinno=sc.nextInt();
		String a=String.valueOf(pinno);
		if(a.length()==4)
		{
			sql="select * from accountdetail where pinno="+pinno;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				System.out.println("Enter the Withdraw Amount:");
				withdraw_amount=sc.nextInt();
				if(withdraw_amount<rs.getFloat("accountbalance")&&withdraw_amount<20000)
				{
					float amount=rs.getFloat("accountbalance")-withdraw_amount;
					sql="update accountdetail set accountbalance="+amount+" where pinno="+pinno;
					i=st.executeUpdate(sql);
					if(i>0)
					{
						System.out.println("your withdraw amount is Rs."+withdraw_amount);
						System.out.println("Available Balance is Rs. "+amount);
					}
				}//withdraw amount checking if is end
				else
				{
					System.out.println("YOUR ATM LIMIT IS 20000 (OR) INSUFFICIENT BALANCE");
				}
			}// rs.next if is end
			else
			{
				System.out.println("INVALID PIN NUMBER......");
			}
		}
		else
		{
			System.out.println("PLEASE ENTER THE 4 DIGIT ATM PIN NUMBER......!");
		}
	}//withdraw end

	//DEPOSIT AMOUNT
	public static void depositAmount() throws SQLException
	{
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the Pin Number:");
		pinno=sc.nextInt();
		String a=String.valueOf(pinno);
		if(a.length()==4) 
		{
			sql="select * from accountdetail where pinno="+pinno;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				System.out.println("Enter the deposit amount:");
				deposit_amount=sc.nextInt();
				float amount=rs.getFloat("accountbalance")+deposit_amount;
				sql="update accountdetail set accountbalance="+amount+" where pinno="+pinno;
				i=st.executeUpdate(sql);
				if(i>0)
				{
					System.out.println("your deposite amount is: "+deposit_amount);
					System.out.println("your currenct balance is; "+amount);
				}
			}
			else
			{
				System.out.println("INVAILD PIN NUMBER......");
			}
		}
		else
		{
			System.out.println("PLEASE ENTER THE 4 DIGIT ATM PIN NUMBER......!");
		}
	}//deposit end

	//VIEW MINI BALANCE
	public static void viewMiniBalance() throws SQLException
	{
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the 4 Digit Pin Number:");
		pinno=sc.nextInt();
		String a=String.valueOf(pinno);
		if(a.length()==4) 
		{
			sql="select * from accountdetail where pinno="+pinno;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				LocalDateTime current=LocalDateTime.now();
				System.out.println("..............MINI STATEMENT...............");
				System.out.println("         $$$-WELCOME TO SAFE ATM-$$$       ");
				System.out.println("      DATE AND TIME :"+current+"\n");
				System.out.println("your account number is :"+rs.getString("ano"));
				System.out.println("Account type is: "+rs.getString("accounttype"));
				System.out.println("Avaliable Balance is RS."+rs.getInt("accountbalance"));
				System.out.println("Your current withdraw amount is RS. "+withdraw_amount);
				System.out.println("Your current deposit amount is RS. "+deposit_amount);
				System.out.println("................THANK YOU...................");
			}
			else
			{
				System.out.println("INVALID PIN NUMBER......");
			}
		}
		else
		{
			System.out.println("PLEASE ENTER THE 4 DIGIT ATM PIN NUMBER.......!");
		}

	}// view balance end

		

	public static void exitPage()
	{
		System.out.println("ENDING THE PROCESS.....THANK YOU......");
		System.out.println(".........../HAVE A GOOD DAY/...........");
		System.exit(0);

	}





}
