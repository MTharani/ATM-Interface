package com.safAtm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ChangePin 
{
	private static Connection scon;
	private static ResultSet rs;
	private static Statement st;
	private static int pinno,i;
	private static String sql;
	private static Scanner sc=new Scanner(System.in);

	public static void changePinNumber() throws SQLException
	{
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		System.out.println("Enter the 10 Digit Account Number:");
		String ano=sc.next();
		if(ano.length()==10) 
		{
			sql="select * from accountholder where ano='"+ano+"'";
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				int max=9000;
				int min=1000;
				int range=max-min+1;
				int otppin=(int) ((Math.random()*range)+min);
				String sql1="update accountholder set otppin="+otppin+" where ano='"+ano+"'";
				i=st.executeUpdate(sql1);
				if(i>0)
				{
					sql="select otppin from accountholder where ano='"+ano+"'";
					rs=st.executeQuery(sql);
					if(rs.next())
					{
					int otp=rs.getInt("otppin");
					System.out.println("Enter Your 4 Digit OTP Number: ");
				    int otpno=sc.nextInt();
				    if(otp==otpno) 
				    {	    
					    
						System.out.println("Enter the New Pin: ");
						pinno=sc.nextInt();
						System.out.println("Conform your pin number:");
						int pinno1=sc.nextInt();
						if(pinno1==pinno) 
						{
							sql="update accountdetail set pinno="+pinno+" where ano='"+ano+"'";
							i=st.executeUpdate(sql);
							if(i>0)
							{
								System.out.println("YOUR PIN IS CHNAGED SUCCESSFULLY......");
							}
						}
				    }
					}
				    else
				    {
				    	System.out.println("PLEASE ENTER VALID OTP NUMBER");
				    }
				}
			}
		}
		else
		{
			System.out.println("PLEASE ENTER VALID 10 DIGIT ACCOUNT NUMBER");
		}
		
	}
	}


