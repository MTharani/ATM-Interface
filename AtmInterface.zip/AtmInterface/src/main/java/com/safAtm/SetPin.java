package com.safAtm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SetPin 
{
	private static Connection scon=null;
	private static ResultSet rs=null;
	private static Statement st=null;
	private static String sql;
	private static int otppin,i;
	private static Scanner sc= new Scanner(System.in);

	private static void generateOtp() 
	{
		int max=9000;
		int min=1000;
		int range=max-min+1;
		otppin=(int) ((Math.random()*range)+min);

	}


	//set a new pin in new ATM card holder
	public static void setPin() throws SQLException
	{
		//FETCHING THE ATM CARD NUMBER IN PARTICULAR CARDHOLDER
		System.out.println("Enter the  4 Digit ATM Card Number:");
		int cardno=sc.nextInt();
		scon=Dbconnection.getConnection();
		st=scon.createStatement();
		String a=String.valueOf(cardno);
		if(a.length()==4) //1
		{
			sql="select * from accountdetail where cardno="+cardno;
			rs=st.executeQuery(sql);
			if(rs.next()) //2
			{
				//FETCHING THE ACCOUNT NUMBER IN PARTICULAR CARDHOLDER
				System.out.println("enter the 10 Digit Account Number");
				String ano=sc.next();
				if(ano.length()==10) //3 
				{
					sql="select * from accountdetail where ano="+ano;
					rs=st.executeQuery(sql);
					if(rs.next()) //4
					{
						//GENERATE A NEW PIN IN ATM CARDHOLDER
						generateOtp();
						String sql1="update accountholder set otppin="+otppin+" where ano='"+ano+"'";
						i=st.executeUpdate(sql1);
						if(i>0) //5
						{
							sql="select otppin from accountholder where ano='"+ano+"'";
							rs=st.executeQuery(sql);
							if(rs.next()) //6
							{
								int otp=rs.getInt("otppin");
								System.out.println("Enter Your 4 Digit OTP Number: ");
								int otpno=sc.nextInt();
								if(otp==otpno) //7 
								{	    
									System.out.println("Enter new pin number:");
									int pinno=sc.nextInt();
									sql="update accountdetail set pinno="+pinno+" where ano="+ano;
									i=st.executeUpdate(sql);
									if(i>0)  //8
									{
										System.out.println("NEW PIN GENERATE SUCCESSFULLY...");
										System.out.println("THANK YOU....");
									} //8 end

									else
									{
										System.out.println("THE PIN NUMBER IS ALREADY EXIT....");
									}
								}//7 end
								else
								{
									System.out.println("Please enter valid OTP Number");
								}
							}//6
						}//5
					}//4
				}//3
				else
				{
					System.out.println("INVALID ACCOUNT NUMBER(or) PLEASE ENTER THE 10 DIGIT ACCOUNT NUMBER");
				}
			}//2 if is closed
		}// 1 IF  IS CLOSED
		else
		{
			System.out.println("INVALID CARD NO (OR) PLEASE ENTER 4 DIGIT ATM CARD NUMBER.......");
		}

	}
}
