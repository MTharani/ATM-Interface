package com.safAtm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class LoginPage 
{
	private static Connection scon=null;
	private static ResultSet rs=null;
	private static Statement st=null;
	private static int cardno;
	private static String sql;
	private static Scanner sc=new Scanner(System.in);
	public static void logIn() throws SQLException 
	{
		//FETCHING THE ATM CARD NUMBER IN PARTICULAR CARDHOLDER
		System.out.println("Enter the  4 Digit ATM Card Number:");
		cardno=sc.nextInt();
		String a=String.valueOf(cardno);
		if(a.length()==4) 
		{
			scon=Dbconnection.getConnection();
			st=scon.createStatement();
			sql="select * from accountholder where cardno="+cardno;
			rs=st.executeQuery(sql);  //EXECUTE THE QUERY
			if(rs.next())
			{
				rs.getInt("cardno");
				System.out.println(             "WELCOME "+rs.getString("aname"));
				System.out.println("========================================================");
				System.out.println("1.VIEW BALANCE \t\t\t  2.WITHDRAW AMOUNT");
				System.out.println("3.DEPOSIT AMOUNT \t\t 4.VIEW MINI STATMENT");
				System.out.println("5.CHANGE ATM PIN NUMBER\t\t6.CANCEL");
				System.out.println("==========================================================");
				System.out.println("Enter the option:");
				int choice=sc.nextInt();
				switch(choice)
				{
				case 1: AtmOperation.checkBalance();
				break;
				case 2: AtmOperation.withdrawAmount();
				break;
				case 3: AtmOperation.depositAmount();
				break;
				case 4: AtmOperation.viewMiniBalance();
				break;
				case 5: ChangePin.changePinNumber();
				break;
				case 6: AtmOperation.exitPage();
				break;
				default: System.out.println("Invalid choice....");
				}
			}
		
		else
		{
			System.out.println("PLEASE ENTER THE CORRECT ATM CARD NUMBER!.....");
		}
		}
		else
		{
			System.out.println("PLEASE ENTER 4 DIGIT ATM CARD NUMBER");
		}

	}

}
